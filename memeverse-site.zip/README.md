# MemeVerse – Viral Hub

## Files
- `index.html` – poori website (layout, styles, logic). Isse baar-baar change karne ki zarurat nahi.
- `features.json` – saare features ka data. Naya feature yahan add karo, code change nahi.

## Owner access setup (sirf aap features add kar paoge)

1. Browser me page kholo aur DevTools console (F12) me yeh chalao, `aapka-password` ki jagah apna password likho:
   ```js
   sha256("aapka-password").then(console.log)
   ```
2. Jo hash print hoga use `index.html` me `ADMIN_HASH = "PASTE_HASH_HERE"` ki jagah paste karo, aur file phir se deploy karo.
3. Admin mode kholne ke liye URL ke end me `#admin` lagao, jaise `https://your-site.netlify.app/#admin`, phir password daalo.
4. Visitors ko `+ Add Feature` button nahi dikhega.

> Note: Yeh ek static site hai, isliye yeh protection sirf normal visitors ko rokta hai. Koi technical user page ka source dekh kar bypass kar sakta hai. Asli security ke liye Netlify ka "Password protection" (paid plan) ya Cloudflare Access use karo. Aur sab visitors ke liye naya feature dikhane ke liye `features.json` me add karke redeploy karna hoga.

## Naya feature kaise add karein (bina code)

### Option 1: Admin panel (turant test karne ke liye)
1. Top-right par **+ Add Feature** dabao.
2. Title, Type (Roast / Card / Sound / Clicker), Color, Description aur Content bharo.
3. **Save & Live Karo** – feature turant page par dikhega.
4. **Export JSON** dabao, jo JSON aaye use copy karke `features.json` me add karo (final publish ke liye).

### Option 2: features.json me seedha add karo
```json
{
  "id": "meme-quiz",
  "type": "card",
  "title": "Meme Quiz 2026",
  "icon": "fa-brain",
  "color": "info",
  "desc": "Quiz ka description",
  "items": ["Question 1 ...", "Question 2 ..."]
}
```

## Feature types
| type | content format |
|------|----------------|
| `roast` | `items`: `[{ "title": "...", "text": "..." }]` |
| `card` | `items`: `["text1", "text2"]` – button se random dikhega |
| `sound` | `items`: `[{ "label": "...", "src": "audio.mp3" }]` |
| `clicker` | koi items nahi chahiye |

Color options: `warning`, `info`, `danger`, `success`.

## Live publish karne ke options (free)

**A. Netlify Drop (sabse aasaan)**
1. https://app.netlify.com/drop par jao.
2. Poora `memeverse` folder drag-and-drop karo.
3. Milega ek live link, jaise `https://xyz.netlify.app`.

**B. GitHub Pages**
1. GitHub par naya repo banao, `index.html` aur `features.json` upload karo.
2. Settings → Pages → Branch `main` select karo.
3. Link: `https://username.github.io/repo-name/`

**C. Vercel**
1. https://vercel.com par folder import karo, ya `vercel` CLI se deploy karo.

> Note: `features.json` ko fetch karne ke liye page ko HTTP(S) par host karna hoga. Local me file ko double-click karne par bhi page chalega, bas wahan default features dikhenge.

## Sound files
Audio files (MP3) ko `features.json` me `src` me daal do. Ye folder me saath rakho, jaise `sounds/bruh.mp3`.

## Ads
Ad slots `index.html` me hain (`ad-banner`). Google AdSense ya koi bhi ad code wahan paste kar sakte ho.
